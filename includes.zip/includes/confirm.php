<?php

echo "cazzo";
/* Header('Location: ') */